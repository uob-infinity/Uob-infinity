document.addEventListener("DOMContentLoaded", function () {
  let userLang = navigator.language || navigator.userLanguage;
  applyLanguage(userLang);
});

function applyLanguage(lang) {
  const translations = {
    en: { welcome: "Welcome", login: "Log In" },
    id: { welcome: "Selamat Datang", login: "Masuk" }
  };
  let selectedLang = lang.startsWith("id") ? "id" : "en";
  document.querySelector(".welcome-text").innerText = translations[selectedLang].welcome;
  document.querySelector(".login-button").innerText = translations[selectedLang].login;
}

function togglePassword() {
  let passwordField = document.getElementById("password");
  passwordField.type = passwordField.type === "password" ? "text" : "password";
}

function validateLogin() {
  let orgId = document.getElementById("org-id").value.trim();
  let userId = document.getElementById("user-id").value.trim();
  let password = document.getElementById("password").value.trim();
  if (!orgId || !userId || !password) {
    alert("Please fill in all fields.");
    return;
  }
  alert("Login successful!");
}
